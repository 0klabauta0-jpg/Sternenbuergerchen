# R7 Untersuchung

Basis d77a37422, neue Branchfortsetzung. Fremdlast SteelDivision2 weiter
autorisiert; keine Prozesse beendet. Preflight2535 alte untracked Dateien
gepinnt; bisherige R6-/Originalschutzchecks vor Start bestanden.

Frische normale Baseline68/0: Max91.517ms, P99 47.476ms, keine erneute196ms.
Der R6-Spitzenwert bleibt historischer Gegenbeleg, kein aktuelles reproduziertes
Limit. Eigene Audits waren im nativen Fenster pausiert.

Erweiterte CPUlesekettenprobe: Light5 Refreshes33.528ms, Full5=248.427ms.
Ensure-ReadModels45/187 Aufrufe nur0.326/1.594ms inklusive; keine
_object_has_property-Aufrufe im Fenster. Kein entsprechender Patch gerechtfertigt.
Der erste Auditversuch scheiterte an falscher Probeoverride-Signatur;
Fehllog erhalten, Signatur auf Original(Array=[]) korrigiert, Retry gruen.

LOSquelle zeigt zwei identische Rangechecks fuer zugelassene Terrainqueries.
RED30/2 ohne Enginefehler, genau beide Aufbauzaehler rot. GREEN32/0;
erweitert48/0 mit Full-/Dirty-Fogoracle in7er-Slices und atomarer Publikation.
2560 admit-Queries:5120->2560 Rangeauswertungen. Paarlauf Hex66.444->59.394ms,
Square47.055->37.286ms. Verschachtelte Kosten/kleine Samples sind kein FPSbeweis.

Source-/Testreview ohne Blocker. Virtuelle Terrainentry wird nun auch bei
abgelehnter Punktquery erreicht, deren voller Guard lehnt vor Traversierung ab.
Keine produktiven Overrides gefunden. Dependencybinding verbindet geerbten
R4-Verifier/TerrainTileData separat mit unveraenderten Basebytes; Paket und
Mainabschluss pruefen dieselben Hashes. Per-case Runnerpins sind nicht als
vollstaendige transitive Dependencyinventur dargestellt.

Finalmatrix und normale Nachlaeufe/Mainabschluss separat in Originalreports.
Kein spekulativer OS-/GPU-/Presentpatch oder Qualitaets-/Gameplayabbau.
