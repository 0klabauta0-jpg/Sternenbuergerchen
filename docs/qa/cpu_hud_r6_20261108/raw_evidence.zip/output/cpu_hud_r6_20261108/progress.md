# CPU/HUD R6 ledger
Task: docs/tasks/CPU_HUD_R6_2026_11_08.md
Base320e3b57e; branch codex/cpu-hud-r6-20261108. Original1415/502/real-roster and previous R5 preservation green;2337 additional startfiles pinned.
- Native before90s68/0, exit0/errors0: cpu_hud_r6_native_before/20261108T174948Z-2e13263a. P99=152.130ms max165.340ms, primary P95=32.499ms max33.719ms. Foreign SteelDivision2 still running; no isolated FPSclaim.
- Original source read-chain audit5Full:135 Use-State reads,195 Binding reads,354.236ms total/inclusive Use-State54.986ms.5Light35/50,54.192ms total.
- RED17/3 errors0: scoped3 repeated builds, actualLight7 andFull27 builds per generation. Other original-payload/freshness/owner cases passed.
- Exactly8-line wrapper uses existing ReadModel.project; original producer moved unchanged, helper unchanged. GREEN20/0; nonempty frontier21/0; actual UI parity24/0. Expanded nonvacuous4sink checks now final91matrix.
- Source review r6_source_review found no blocking defect. Limitation: real interaction-command callback during an active cached pass not injected; synthetic context boundaries and independent command/authority/reentry gates complement each other.
-91gate matrix running; no further product changes. Native afterA/B and Main flow pending.
- Ruling: continue from just-integrated current Main rather than stale integration/core-foundation as explicitly requested follow-on. Cost: no unrelated integration-branch work included.
- Ruling: previously authorized foreign GPUload remains untouched; complete requested measurements with explicit attribution limits.

- Final matrix91/91 exit0/errors0/privateguard/sourcepins stable. Both R6 fixtures26/0. Six new interaction neighbors green.
- Read-chain after: public Use-State calls unchanged35/135 per5Light/Full; Binding builds50->20 /195->65; sourcecontext7/27 ->1 perpass.5Lighttotal54.192 ->47.563ms,5Full354.236 ->341.781ms (synthetic timings, not FPS).
- Native afterA/B68/0 each. HUD primary P95 32.499 ->26.825/28.643ms; max33.719 ->29.200/31.117ms. Wholeframe max165.340 ->196.071/168.971ms, P99152.130 ->152.656/155.048ms (worse tails); publicMoveGO median71.904 ->74.497/74.361ms (no overall commandcost gain). All counterevidence retained.
- Same11units/7acceptedMoveGO/1x/camera22/fullquality, max1managerjob/frame, nav/effectpendingmax0, commandqueuemax7, max8ticks/render. Native before/after originals opened.
- Additional GPU boundary run70/0,936 matched rows, median gameGPU73.386ms; diagnostic-only frame181.008ms with114.689ms pre/post wall interval, GPU last-value16.474ms near read, not same-frame cause proof. Displayfactsmax757us. No extra source fix justified.
