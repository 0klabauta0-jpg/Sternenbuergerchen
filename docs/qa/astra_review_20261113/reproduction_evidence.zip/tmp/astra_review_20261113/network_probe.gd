extends SceneTree
## Read-only review reproducer: actual loopback RPC and production authority
## methods, synthetic scene/content, manually stepped; no product-file writes.
const SIM = preload("res://scripts/core/simulation_root.gd")
const DRIVER = preload("res://scripts/tests/mission_combat_loop_driver.gd")
const UNIT = preload("res://scripts/npc/test_unit.gd")
const REGISTRY = preload("res://scripts/registries/unit_registry.gd")
const GUARD = preload("res://scripts/tests/review2_isolated_user_guard.gd")
var passed := 0
var failed := 0
var accepts: Array = []
var responses: Array = []

func _init() -> void:
	if GUARD.require_isolated_user_data(): call_deferred("_run")

func check(value: bool, label: String) -> void:
	if value: passed += 1
	else: failed += 1
	print("PASS " if value else "FAIL ", label)

func fixture(label: String, api: SceneMultiplayer, authority: bool) -> Dictionary:
	var scope := Node.new()
	scope.name = label
	root.add_child(scope)
	set_multiplayer(api, scope.get_path())
	var registry = REGISTRY.new()
	registry.name = "UnitRegistry"
	scope.add_child(registry)
	var sim = SIM.new()
	sim.name = "SimulationRoot"
	sim.unit_registry_path = NodePath("../UnitRegistry")
	sim.is_server_authoritative = true
	scope.add_child(sim)
	sim.set_process(false)
	sim.set_physics_process(false)
	var unit = UNIT.new()
	unit.name = "Own"
	unit.unit_id = "review_own"
	unit.team_id = "team_alpha"
	unit.fireteam_id = "blue"
	unit.position = Vector2(32, 32)
	scope.add_child(unit)
	unit.set_process(false)
	registry.register_unit(unit.unit_id, unit)
	sim.register_known_unit(unit.unit_id, unit)
	var driver = DRIVER.new()
	driver.name = "CombatLoopDriver"
	driver.preview_mode = true
	driver.simulation_root_path = NodePath("../SimulationRoot")
	driver.friendly_unit_paths.assign([NodePath("../Own")])
	scope.add_child(driver)
	driver.set_process(false)
	driver.set_physics_process(false)
	if authority:
		# Authored station: nonzero required duration and a remote interaction marker.
		driver.configure_scenario_runtime_gates({
			"flow_steps": [{"step_id":"review_station_upload", "objective_type":"computer_hold", "operator_team_id":"team_alpha", "min_hold_seconds":30.0, "required_state":"uploaded", "target_marker_id":"remote_station"}],
			"interaction_points": [{"interaction_id":"review_terminal", "interaction_type":"computer", "marker_id":"remote_station", "duration_seconds":30.0, "radius_world":48.0, "step_id":"review_station_upload", "gate_id":"review_station_upload", "required_state":"uploaded", "required_order":"take", "required_team":"team_alpha"}]
		})
	return {"scope":scope, "sim":sim, "unit":unit, "driver":driver}

func wait_network() -> void:
	await create_timer(0.18).timeout

func _run() -> void:
	var server := ENetMultiplayerPeer.new()
	check(server.create_server(0, 1) == OK, "loopback host starts")
	var host_api := SceneMultiplayer.new()
	host_api.multiplayer_peer = server
	var peer := ENetMultiplayerPeer.new()
	check(peer.create_client("127.0.0.1", server.host.get_local_port()) == OK, "loopback client starts")
	var client_api := SceneMultiplayer.new()
	client_api.multiplayer_peer = peer
	var host := fixture("Host", host_api, true)
	var client := fixture("Client", client_api, false)
	var deadline := Time.get_ticks_msec() + 5000
	while (peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED or host_api.get_peers().is_empty()) and Time.get_ticks_msec() < deadline:
		await create_timer(0.01).timeout
	check(peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED and host_api.get_peers().size() == 1, "actual ENet handshake")
	var peer_id := client_api.get_unique_id()
	host.sim.set_peer_team(peer_id, "team_alpha")
	host.sim.set_peer_role(peer_id, "fireteam")
	host.sim.set_peer_fireteams(peer_id, PackedStringArray(["blue"]))
	var context := {"schema":"multiplayer.runtime_context.v1", "runtime_token":"ab".repeat(16), "map_id":"astra_network_review", "map_hash":"a".repeat(64)}
	check(host.sim.bind_multiplayer_runtime_context(context, "team_alpha").ok and client.sim.bind_multiplayer_runtime_context(context, "team_alpha").ok, "same verified runtime context bound")
	host.sim.network_command_accepted.connect(func(command: Dictionary, sender: int): accepts.append({"command":command, "sender":sender}))
	client.sim.network_command_result_received.connect(func(result: Dictionary): responses.append(result))
	var before: Dictionary = host.driver.get_mission_scenario_runtime_gate_snapshot()
	check(not before.get("all_gates_complete", true), "authored 30-second computer objective initially incomplete")
	var interaction := {
		"contract_category":"commander_command", "command_type":"take", "unit_id":"review_own", "team_id":"team_alpha", "fireteam_id":"blue", "target_position":Vector2(32,32),
		"source_context":"mission_interaction_use_intent_command", "interaction_id":"review_terminal", "interaction_type":"computer", "interaction_radius_world":100000.0, "duration_seconds":0.0,
		"step_id":"review_station_upload", "gate_id":"review_station_upload", "required_state":"uploaded"
	}
	client.sim.submit_multiplayer_command(interaction)
	await wait_network()
	check(accepts.size() == 1 and accepts[0].sender == peer_id and responses.size() == 1 and responses[0].accepted, "production RPC accepts client-modified interaction metadata as nonhost fireteam")
	host.driver._advance_pending_network_mission_interactions(0.01)
	var after: Dictionary = host.driver.get_mission_scenario_runtime_gate_snapshot()
	var states: Dictionary = host.driver.get_mission_interaction_runtime_states()
	check(states.get("review_terminal", {}).get("complete", false) and after.get("all_gates_complete", false), "REPRO: host completes authored 30-second objective in 0.01 seconds from client metadata")
	var modifiers := {"command_type":"hold_position", "unit_id":"review_own", "team_id":"team_alpha", "fireteam_id":"blue", "move_speed_factor":100.0, "sight_range_factor":50.0, "attack_bonus":100.0, "cover_score":1000.0}
	client.sim.submit_multiplayer_command(modifiers)
	await wait_network()
	check(accepts.size() == 2 and accepts[1].sender == peer_id and responses.size() == 2 and responses[1].accepted, "production RPC accepts client-authored combat modifiers")
	var commands: Array = host.sim.command_queue.duplicate(true)
	host.sim.command_queue.clear()
	host.sim._process_commands(commands, 0.1)
	var observed := {"attack_bonus":host.unit.get_attack_bonus(), "move_speed_factor":host.unit.get_move_speed_factor(), "sight_range_factor":host.unit.get_sight_range_factor(), "cover_score":host.unit.get_runtime_status().cover_score}
	check(observed.attack_bonus == 100.0 and observed.move_speed_factor == 100.0 and observed.sight_range_factor == 50.0 and observed.cover_score == 1000.0, "REPRO: production TestUnit now owns client-supplied combat/speed/sight modifiers")
	print("ASTRA_NETWORK_REVIEW ", JSON.stringify({"real_enet":true, "checks":passed+failed, "failures":failed, "accepted_remote_commands":accepts.size(), "objective_before":before, "objective_after":after, "unit_modifiers_after":observed, "manual_authority_steps":true, "synthetic_content":true}))
	server.close()
	peer.close()
	host.scope.free()
	client.scope.free()
	await process_frame
	print("ASTRA_NETWORK_REVIEW_DONE checks=%d failures=%d" % [passed+failed,failed])
	quit(0 if failed == 0 else 1)
