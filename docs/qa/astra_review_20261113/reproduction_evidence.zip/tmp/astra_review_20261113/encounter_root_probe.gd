extends SceneTree
## Real Root/Adapter/Fleet/Combat/Encounter at a synthetic completed-boundary fixture.
## Departure receipt/phase are explicit setup, not evidence of a five-mission run.
const GRID = preload("res://scripts/core/strategic_hex_grid.gd")
const CATALOG = preload("res://scripts/mission/space_component_catalog.gd")
var failed := 0
func _initialize() -> void:
	var fleet = load("res://scripts/core/singleplayer_fleet_travel_state.gd").new()
	check(fleet.configure().get("ok",false),"fleet configured")
	var craft := "review_player"
	fleet.register_craft(craft)
	var travel = fleet.get("_owners")[craft]
	travel.set("_phase","approach")
	travel.set("_craft_id",craft)
	travel.set("_location_id","distress_orbit")
	travel.set("_orbit_id","planet_orbit")
	var supply = load("res://scripts/core/singleplayer_supply_state.gd").new()
	check(supply.configure([{"craft_id":craft}]).get("ok",false),"supply configured")
	var sim = load("res://scripts/core/simulation_root.gd").new()
	sim.is_server_authoritative = false
	var adapter = load("res://scripts/meta/singleplayer_runtime_adapter.gd").new()
	var encounter = load("res://scripts/core/campaign_space_encounter.gd").new()
	sim.configure_singleplayer_owners(null,supply,null,fleet)
	check(sim.configure_departure_adapter(adapter).get("ok",false),"actual adapter bound to Root")
	sim.configure_space_encounter(encounter)
	adapter.set("_simulation",sim)
	adapter.set("_travel",fleet)
	adapter.set("_supply",supply)
	adapter.set("_space_encounter",encounter)
	adapter.set("_departure_token_by_craft",{craft:"review-departure"})
	var combat: RefCounted = sim.get("_space_combat_state")
	var ids := {"player":craft,"hostile":"hostile_cutlass","neutral":"neutral_buccaneer"}
	for role in ["player","hostile","neutral"]:
		var cell := Vector2i(10+["player","hostile","neutral"].find(role)*3,10)
		var flight: RefCounted = fleet.get_flight_state(craft) if role=="player" else load("res://scripts/core/space_flight_state.gd").new()
		check(flight.configure(ids[role],{"position_plane":Vector2.ZERO}).get("ok",false),role+" strategic flight configured")
		var proposal := {"expected_revision":flight.get_snapshot().revision,"coordinate_frame":"local","space_area_id":"orbit_approach:planet","position_plane":GRID.HEX.axial_to_plane(Vector2(cell)),"motion_mode":"tactical","heading_rad":0.0}
		var movement: Dictionary = flight.validate_area_transition(proposal,1)
		var admitted: Dictionary = combat.validate_new_local_admission({"craft_id":ids[role],"faction_id":role,"control_domain":"enemy" if role=="hostile" else role,"footprint_hexes":[Vector2i.ZERO]},flight,proposal,1)
		print("ASTRA_ADMISSION ",role," ",movement.get("reason","ok")," / ",admitted.get("reason","ok"))
		check(movement.get("ok",false) and admitted.get("ok",false),role+" actual local-area admission preflight")
		if movement.get("ok",false) and admitted.get("ok",false):
			flight._publish_area_transition(movement)
			combat._publish_new_local_admission(admitted)
			var systems: Dictionary = combat.bind_ship_systems(ids[role],CATALOG.effective_stats("buccaneer",CATALOG.default_loadout("buccaneer")),8.0)
			print("ASTRA_SYSTEMS ",role," ",systems)
			check(systems.get("ok",false),role+" ship systems bound")
	if failed>0:
		adapter.free(); sim.free(); print("ASTRA_ENCOUNTER_ROOT_PROBE fixture_failed=",failed); quit(2); return
	check(encounter.start_encounter(craft,true).get("ok",false),"encounter enters prepared phase")
	var bound: Dictionary = sim.bind_campaign_space_combat(ids,{"runtime_authorized":true})
	print("ASTRA_BIND ",bound)
	check(bound.get("ok",false),"Root binds actual fleet flight and combat actors")
	if failed>0:
		adapter.free(); sim.free(); print("ASTRA_ENCOUNTER_ROOT_PROBE fixture_failed=",failed); quit(2); return
	# Synthetic earlier transaction evidence, containing exact live owner identities.
	sim.get("_departure_group_receipts")["review-departure"]={"craft_id":craft,"result":{"departure":{"destination_location_id":"distress_orbit"}},"supply":supply,"supply_epoch":supply.get("_route_prepare_epoch"),"fleet":fleet,"flight":fleet.get_flight_state(craft)}
	var retreat: Dictionary = sim.request_singleplayer_command({"contract_category":"campaign_space","operation":"retreat","payload":{},"request_id":"review-retreat"})
	check(retreat.get("ok",false) and encounter.get_snapshot().phase=="aborted","actual Root command terminates bound encounter")
	var result: Dictionary = sim.commit_campaign_space_return(adapter,craft,"encounter-return:review-departure")
	print("ASTRA_FINDING_ENCOUNTER_ROOT ",JSON.stringify(result))
	check(not result.get("ok",false) and result.get("reason")=="invalid_area_context","OBSERVED DEFECT: real Root return rejects its own end-encounter context")
	adapter.call("_finish_space_encounter_result")
	var state: Dictionary = encounter.get_snapshot()
	print("ASTRA_FINDING_ENCOUNTER_ADAPTER ",JSON.stringify({"phase":state.phase,"resolved":state.resolved,"travel_phase":fleet.get_craft_snapshot(craft).phase,"pending_result":not encounter.peek_completed_result().is_empty()}))
	check(state.phase=="aborted" and not state.resolved and fleet.get_craft_snapshot(craft).phase=="approach","OBSERVED DEFECT: adapter leaves terminal encounter unresolved and craft in approach")
	adapter.free()
	sim.free()
	print("ASTRA_ENCOUNTER_ROOT_PROBE failed=",failed)
	quit(1 if failed else 0)
func check(ok: bool,label: String) -> void:
	if not ok: failed+=1
	print("PASS: " if ok else "FAIL: ",label)
