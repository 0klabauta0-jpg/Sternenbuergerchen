extends SceneTree
const GUARD = preload("res://scripts/tests/review2_isolated_user_guard.gd")
var presses := 0
func _init() -> void:
	if GUARD.require_isolated_user_data(): call_deferred("_run")
func _run() -> void:
	var scene := Control.new()
	scene.name = "UnderlyingGameUI"
	root.add_child(scene)
	current_scene = scene
	var button := Button.new()
	button.name = "UnderlyingAction"
	button.text = "Underlying action"
	button.position = Vector2(20,20)
	button.size = Vector2(180,60)
	button.pressed.connect(func(): presses += 1)
	scene.add_child(button)
	await process_frame
	button.grab_focus()
	var shell: Node = root.get_node("GlobalEscapeMenu")
	shell.call("set_test_mode", true)
	var escape := InputEventKey.new()
	escape.keycode = KEY_ESCAPE
	escape.pressed = true
	root.push_input(escape, true)
	await process_frame
	var focus := root.gui_get_focus_owner()
	print("UI_PROBE menu_visible=", shell.call("is_menu_visible"), " focus=", focus.name if focus else "none")
	var enter := InputEventKey.new()
	enter.keycode = KEY_ENTER
	enter.pressed = true
	root.push_input(enter, true)
	await process_frame
	enter = enter.duplicate()
	enter.pressed = false
	root.push_input(enter, true)
	await process_frame
	print("UI_PROBE underlying_button_presses=", presses, " expected=0 menu_visible=", shell.call("is_menu_visible"))
	shell.call("close_menu")
	current_scene = null
	scene.queue_free()
	await process_frame
	print("UI_PROBE_FINISHED")
	quit(0)
