extends "res://tmp/astra_review_20261113/hex_probe.gd"
const COMMAND = preload("res://scripts/npc/unit_command.gd")

class ReaderRoot extends Node:
	var registry: Node
	func get_unit_registry() -> Node: return registry

class DiagnosticNPC extends NPC:
	var command = COMMAND.new({"command_type":"hold_position", "fire_status":"hold_fire", "fire_rule":"return"})
	func get_current_unit_command(): return command
	func get_fire_status() -> String: return "hold_fire"
	func get_discipline() -> float: return 0.0

func _run() -> void:
	var scope := Node.new()
	scope.name = "DiagnosticReviewScope"
	root.add_child(scope)
	var registry = UNITS.new()
	registry.name = "UnitRegistry"
	scope.add_child(registry)
	var owner := ReaderRoot.new()
	owner.name = "SimulationRoot"
	owner.registry = registry
	scope.add_child(owner)
	var driver := QuietDriver.new()
	driver.name = "CombatLoopDriver"
	driver.friendly_team_id = "blue"
	driver.simulation_root_path = NodePath("../SimulationRoot")
	scope.add_child(driver)
	var own := DiagnosticNPC.new()
	own.name = "Own"
	own.unit_id = "own"
	own.team_id = "blue"
	scope.add_child(own)
	var enemy := NPC.new()
	enemy.name = "Enemy"
	enemy.unit_id = "enemy"
	enemy.team_id = "red"
	enemy.position = Vector2(100.0,0.0)
	scope.add_child(enemy)
	for unit in [own,enemy]: registry.register_unit(unit.unit_id,unit)
	driver.friendly_unit_paths.assign([NodePath("../Own")])
	driver.enemy_unit_paths.assign([NodePath("../Enemy")])
	# This is the published state immediately before the first enemy arrives.
	driver._last_contact_decision_diagnostics = {"reason":"no_contact_pair", "candidate":{"candidate_reason":"no_enemy_combat_units"}}
	var selected_seed := -1
	var first_roll := -1.0
	for candidate in range(1000):
		seed(candidate)
		var value := randf()
		if value < DRIVER.DISCIPLINE_BREAK_BASE_CHANCE:
			selected_seed = candidate
			first_roll = value
			break
	var before: Dictionary = driver.get_discipline_break_cooldown().duplicate(true)
	seed(selected_seed)
	# Exact public method the live mission-control HUD/feedback reads.
	var readout: Dictionary = driver.get_contact_decision_diagnostics_snapshot()
	var after: Dictionary = driver.get_discipline_break_cooldown().duplicate(true)
	print("HEX_REVIEW_DIAGNOSTIC ", JSON.stringify({"seed":selected_seed, "first_global_roll":first_roll,
		"cooldown_before":before, "cooldown_after":after, "event_after":driver._last_event_text,
		"expected_no_mutation":true, "actual_mutation":before != after, "readout":readout}))
	scope.free()
	await process_frame
	print("HEX_REVIEW_DONE")
	quit(0)
