import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json, os, re, shutil, subprocess, uuid
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('isolation', ROOT/'scripts/tests/run_review2_isolated.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
case = sys.argv[1]
assert re.fullmatch(r'[a-z_]+', case)
probe = Path(__file__).parent/(case+'_probe.gd')
run_id = uuid.uuid4().hex
out = ROOT/'tmp/astra_review_20261113/runs'/(case+'_'+run_id)
out.mkdir(parents=True)
project, app = helper.create_overlay(ROOT, run_id)
entry = project/'tmp'/probe.name
shutil.copy2(probe, entry)
support = project/'tmp/astra_review_20261113'
support.mkdir()
for dependency in probe.parent.glob('*.gd'):
    shutil.copy2(dependency, support/dependency.name)
real_user = Path(os.environ['APPDATA'])/'Godot/app_userdata/Sternenbuergerchen'
def fingerprint(path):
    return {str(p.relative_to(path)):[hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_mtime_ns] for p in path.rglob('*') if p.is_file()} if path.exists() else {}
tracked = subprocess.check_output(['git','ls-files','-z','scripts','scenes','data','project.godot'],cwd=ROOT).decode().split('\0')
def source_hashes():
    return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in tracked if p and (ROOT/p).is_file()}
before_profile, before_sources = fingerprint(real_user), source_hashes()
engine = shutil.which('godot_console.exe')
version = subprocess.check_output([engine,'--version'],text=True).strip()
assert version.startswith('4.6.2.')
user = Path(os.environ['APPDATA'])/'Godot/app_userdata'/app
cmd = [engine,'--headless','--path',str(project),'--script','res://tmp/'+probe.name]
with (out/'output.log').open('wb') as log:
    process = subprocess.Popen(cmd,env=dict(os.environ,SB_REVIEW2_USER_DIR=str(user)),stdout=log,stderr=subprocess.STDOUT)
    try:
        code = process.wait(timeout=150)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
        process.wait(timeout=20)
        code = 124
text = re.sub(r'\x1b\[[0-9;]*m','',(out/'output.log').read_text(encoding='utf-8',errors='replace'))
guards = {'source_unchanged':before_sources==source_hashes(),'real_profile_unchanged':before_profile==fingerprint(real_user),'isolated_user_canary':(user/'review2_isolation_canary.json').is_file()}
errors = re.findall(r'^.*(?:ERROR:|SCRIPT ERROR:|ObjectDB instances leaked|resources still in use at exit).*$',text,re.M)
report = dict(case=case,engine=version,exit_code=code,command=cmd,guards=guards,errors=errors,source_sha256=before_sources,probe_sha256=hashlib.sha256(probe.read_bytes()).hexdigest(),log_sha256=hashlib.sha256((out/'output.log').read_bytes()).hexdigest())
(out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(text[-11000:])
print('REPORT',out/'report.json')
sys.exit(0 if code==0 and all(guards.values()) and not errors else 1)
