extends SceneTree
## Review-only reproducer. No product code changes and no player's user://.
const SIM = preload("res://scripts/core/simulation_root.gd")
const MAP = preload("res://scripts/terrain/terrain_map_data.gd")
const TERRAIN = preload("res://scripts/terrain/terrain_registry.gd")
const TILE = preload("res://scripts/terrain/terrain_tile_data.gd")
const UNITS = preload("res://scripts/registries/unit_registry.gd")
const DRIVER = preload("res://scripts/tests/mission_combat_loop_driver.gd")
const CACHE = preload("res://scripts/mission/combat_visibility_cache.gd")
const QUERY = preload("res://scripts/core/hex_visibility_query.gd")
const SECURITY = preload("res://scripts/tactical/fireteam_security_controller.gd")
const GUARD = preload("res://scripts/tests/review2_isolated_user_guard.gd")

class NPC extends Node2D:
	var unit_id: String
	var team_id: String
	var active_weapon_id := "rifle"
	var is_fireteam_lead := false
	func get_unit_id() -> String: return unit_id
	func get_team_id() -> String: return team_id
	func get_fireteam_id() -> String: return team_id + "_ft"
	func get_vital_state() -> String: return "fit"
	func get_health() -> int: return 100
	func get_awareness() -> float: return 1.0
	func get_active_weapon_id() -> String: return active_weapon_id
	func get_current_unit_command(): return null
	func get_stealth() -> float: return 0.0

class QuietDriver extends DRIVER:
	func _ready() -> void:
		set_process(false)
		set_physics_process(false)

func _init() -> void:
	if GUARD.require_isolated_user_data(): call_deferred("_run")

func _run() -> void:
	var terrain = TERRAIN.new()
	terrain.configure_iso_grid(Vector2.ZERO, 64.0, 32.0, "hex_axial_v1")
	for x in range(3):
		terrain.register_tile(TILE.new({"tile_id":str(x), "grid_position":Vector2i(x,0),
			"explicit_hex_ramps":true, "height_level":2 if x != 1 else 0,
			"ramp_direction":0 if x != 1 else -1,
			"blocks_los":x == 1, "object_height":2 if x == 1 else 0}))
	var observer := {"grid":Vector2i.ZERO, "facing_dir":0,
		"stand_height_steps2":roundi(terrain.get_stand_height_at(Vector2i.ZERO) * 2.0)}
	var target := {"grid":Vector2i(2,0),
		"stand_height_steps2":roundi(terrain.get_stand_height_at(Vector2i(2,0)) * 2.0)}
	var profile := {"range_hex":3, "arc_degrees":120.0}
	var cache = CACHE.new()
	cache.begin_tick(1)
	var pure: Dictionary = QUERY.evaluate(observer, target, terrain, profile)
	var cached: Dictionary = cache.query_hex_visibility(observer, target, terrain, profile)
	print("HEX_REVIEW_RAMP ", JSON.stringify({"observer_height_steps2":observer.stand_height_steps2,
		"target_height_steps2":target.stand_height_steps2, "blocker_top":2,
		"expected_visible":true, "pure":pure, "cached":cached}))
	cache.free()
	terrain.free()

	var scope := Node.new()
	scope.name = "ReviewHexScope"
	root.add_child(scope)
	terrain = TERRAIN.new()
	terrain.name = "TerrainRegistry"
	scope.add_child(terrain)
	terrain.configure_iso_grid(Vector2.ZERO, 64.0, 32.0, "hex_axial_v1")
	for x in range(5):
		terrain.register_tile(TILE.new({"tile_id":str(x), "grid_position":Vector2i(x,0), "explicit_hex_ramps":true}))
	var registry = UNITS.new()
	registry.name = "UnitRegistry"
	scope.add_child(registry)
	var sim = SIM.new()
	sim.name = "SimulationRoot"
	sim.unit_registry_path = NodePath("../UnitRegistry")
	sim.terrain_registry_path = NodePath("../TerrainRegistry")
	scope.add_child(sim)
	sim.set_physics_process(false)
	sim.set_process(false)
	var map = MAP.create_empty("review_hex_probe", Vector2i(5,1), Vector2.ZERO,64,32,3,"hex_axial_v1")
	map.set_tactical_grid_rules("hex_tactical_v1")
	map._extension_metadata["terrain_height_rules"] = "explicit_hex_ramps_v1"
	var configured: Dictionary = sim.configure_hex_ground_runtime(map, terrain)
	cache = CACHE.new()
	cache.name = "VisibilityCache"
	scope.add_child(cache)
	cache.begin_tick(1)
	var driver := QuietDriver.new()
	driver.name = "CombatLoopDriver"
	driver.friendly_team_id = "blue"
	driver.simulation_root_path = NodePath("../SimulationRoot")
	driver.terrain_registry_path = NodePath("../TerrainRegistry")
	driver.combat_visibility_cache_path = NodePath("../VisibilityCache")
	scope.add_child(driver)
	var own := NPC.new()
	own.name = "Own"
	own.unit_id = "own"
	own.team_id = "blue"
	own.active_weapon_id = "none"
	own.position = terrain.grid_to_world(Vector2i(4,0))
	scope.add_child(own)
	var enemy := NPC.new()
	enemy.name = "Enemy"
	enemy.unit_id = "enemy"
	enemy.team_id = "red"
	enemy.position = terrain.grid_to_world(Vector2i.ZERO)
	scope.add_child(enemy)
	for unit in [own,enemy]:
		registry.register_unit(unit.unit_id,unit)
		sim.register_known_unit(unit.unit_id,unit)
	driver.friendly_unit_paths.assign([NodePath("../Own")])
	driver.enemy_unit_paths.assign([NodePath("../Enemy")])
	var placements: Array[Dictionary] = [{"unit_id":"own", "grid":Vector2i(4,0), "facing_dir":3},
		{"unit_id":"enemy", "grid":Vector2i.ZERO, "facing_dir":3}]
	var admitted: Dictionary = sim.admit_hex_ground_units(placements)
	var logical: Dictionary = driver.get_hex_sight_adapter().query_units(enemy, own, 1000.0)
	var contact_los: bool = driver._has_valid_los(enemy,own)
	var pair: Dictionary = driver._find_first_contact_pair()
	print("HEX_REVIEW_REAR_ATTACK ", JSON.stringify({"configured":configured, "admitted":admitted,
		"enemy_ground":sim.get_hex_unit_state("enemy"), "logical_visibility":logical,
		"contact_los":contact_los, "chosen_attacker":pair.get("attacker_id", ""),
		"chosen_target":pair.get("target_id", ""), "detection_delay":driver._get_detection_delay_ticks(enemy),
		"expected_no_attack_pair":true, "actual_attack_pair":not pair.is_empty()}))
	# Do not claim old Overwatch is live: its actual state producer disables it.
	var security = SECURITY.new()
	print("HEX_REVIEW_OVERWATCH_DISABLED ", not security._is_overwatch_ready("defend", {}, {}, {}, [{"unit":enemy}]))
	scope.free()
	await process_frame
	print("HEX_REVIEW_DONE")
	quit(0)
