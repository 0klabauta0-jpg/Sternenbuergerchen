extends "res://scripts/tests/campaign_legacy_satellite_boarding_verifier.gd"
## Read-only review probe. Only fresh, explicitly isolated user:// fixtures.
## PASS means that the stated observation was reproduced, not that the defect is fixed.
const ACTIVE_PATH := "user://campaigns/introduction/active_checkpoint_v1.json"

func _run() -> void:
	if OS.get_environment("SB_REVIEW2_USER_DIR").is_empty() or not OS.get_user_data_dir().contains("SB-Codex-Review2-"):
		printerr("ASTRA_CAMPAIGN_PROBE_REFUSED: private review2 profile required")
		quit(2)
		return
	_configure_entry()
	_flow = FLOW.instantiate()
	root.add_child(_flow)
	current_scene = _flow
	await process_frame
	_screen = _flow.get_node("HomebaseScreen")
	_runtime = _flow.get("_singleplayer_runtime")
	if not await _prepare_initial_base(): await _finish(); return
	_pilot_id = "campaign_pilot"
	_crew_ids = ["campaign_leader"]
	if not _check(_screen.call("request_operation", "accept_job", {"job_id":"satellite_recovery", "request_id":"astra-review:accept"}).get("ok",false), "real campaign job accepted"): await _finish(); return
	if not _check(_screen.call("request_operation", "select_destination", {"location_id":"satellite_crash", "job_id":"satellite_recovery", "request_id":"astra-review:destination"}).get("ok",false), "real campaign location selected"): await _finish(); return
	if not await _launch_and_land("satellite_recovery", "res://maps/satellite_crash_site.json"): await _finish(); return
	var home_before := FileAccess.get_file_as_bytes(STORE.DEFAULT_PATH)
	var saved: Dictionary = _flow.call("request_campaign_save")
	print("ASTRA_ACTIVE_SAVE ", saved)
	if not _check(saved.get("ok",false), "real deployed mission saved through campaign owner"): await _finish(); return
	var mission: Node = _flow.get("_active_mission")
	var controller: Node = mission.get_node("TacticalController")
	for id in ["campaign_leader", "campaign_pilot"]:
		controller.call("_get_campaign_sortie_unit", id).call("apply_damage",10000)
	mission.get_node("CombatLoopDriver").call("_resolve_combat","defeat","enemy")
	await process_frame
	if not _check(bool(Dictionary(_flow.get("_last_mission_result")).get("campaign_checkpoint_retry_required",false)), "actual casualty exposes explicit home checkpoint rollback"): await _finish(); return
	_check(FileAccess.get_file_as_bytes(STORE.DEFAULT_PATH)==home_before, "casualty preserves last home file")
	var button: Button = _flow.get_node("DebriefScreen/Panel/Margin/VBox/ButtonRow/ReturnToHomebaseButton")
	_check(button.text.contains("Checkpoint"), "actual debrief button offers checkpoint continuation")
	button.pressed.emit()
	await process_frame
	await process_frame
	_flow = current_scene
	if not _check(is_instance_valid(_flow), "actual rollback button creates next flow"): await _finish(); return
	_screen = _flow.get_node("HomebaseScreen")
	_runtime = _flow.get("_singleplayer_runtime")
	if not await _wait(func(): return _flow.has_meta("campaign_active_restore_complete") or _flow.has_meta("campaign_active_restore_error"), 60000, "explicit home rollback reaches active-restore decision"): await _finish(); return
	var restored: bool = bool(_flow.get_meta("campaign_active_restore_complete",false)) and is_instance_valid(_flow.get("_active_mission"))
	var phase := String(_runtime.call("get_space_travel_snapshot").get("phase",""))
	print("ASTRA_FINDING_HOME_ROLLBACK ", JSON.stringify({"active_mission_restored":restored,"travel_phase":phase,"home_file_unchanged":FileAccess.get_file_as_bytes(STORE.DEFAULT_PATH)==home_before}))
	_check(restored and phase=="surface", "OBSERVED DEFECT: explicit home rollback instead reloads saved surface mission")
	_flow.queue_free()
	await process_frame
	# An unreadable old active file must not contaminate an entirely new run.
	var corrupt := FileAccess.open(ACTIVE_PATH,FileAccess.WRITE)
	corrupt.store_string("{ invalid old active checkpoint")
	corrupt.close()
	var corrupt_before := FileAccess.get_file_as_bytes(ACTIVE_PATH)
	START.request_start(self,"campaign","new")
	_flow = FLOW.instantiate()
	root.add_child(_flow)
	current_scene = _flow
	await process_frame
	_screen = _flow.get_node("HomebaseScreen")
	_runtime = _flow.get("_singleplayer_runtime")
	var fresh: Dictionary = _flow.call("request_campaign_save")
	print("ASTRA_NEW_HOME_SAVE ",fresh)
	if not _check(fresh.get("ok",false) and STORE.load_checkpoint().get("ok",false), "new campaign produces independently valid home checkpoint"): await _finish(); return
	_check(FileAccess.get_file_as_bytes(ACTIVE_PATH)==corrupt_before,"new campaign keeps unrelated corrupt active file")
	_flow.queue_free()
	await process_frame
	# The actual configuration rejects before touching its flow argument.
	var configuration = load("res://scripts/meta/campaign_start_configuration.gd").new()
	var dummy := Node.new()
	configuration.configure(dummy,{"mode":"campaign","action":"continue"})
	var error: String = configuration.error_message
	print("ASTRA_FINDING_STALE_ACTIVE ",JSON.stringify({"new_home_valid":STORE.load_checkpoint().get("ok",false),"continue_error":error,"corrupt_active_retained":FileAccess.get_file_as_bytes(ACTIVE_PATH)==corrupt_before}))
	_check(not error.is_empty() and error.contains("Einsatzstand"),"OBSERVED DEFECT: old corrupt active file prevents continuing newly saved campaign")
	dummy.free()
	await _finish()

func _finish() -> void:
	if is_instance_valid(_flow): _flow.queue_free()
	await process_frame
	print("ASTRA_CAMPAIGN_PROBE passed=%d failed=%d" % [_passed,_failed])
	quit(1 if _failed else 0)
