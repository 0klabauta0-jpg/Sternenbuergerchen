# CPU/HUD R5 ledger
Task: docs/tasks/CPU_HUD_R5_2026_11_08.md
Base:33bc504c4e8ebdd4e8055e7b1d1fb2fb4924cb49; branch codex/cpu-hud-r5-20261108.
- Original1415/502/real-roster protection green;2154 additional untracked files pinned.
- Native90s before68/0, exit0/errors0: cpu_hud_r5_native_before/20261108T141244Z-527f445b. P99=109.544ms max177.367ms; primaryphase P95=40.494ms max46.373ms. Foreign load remains user-authorized.
- Identity RED33/2 (1063 repeated bootparses over four real Full/Light refreshes); GREEN35/0. Only immutable process config retained; explicit args/live peer unchanged.
- Status fallback RED18/2 -> GREEN20/0. Frozen original RAW/decision oracle equal; real selection/public Move, explicit presentation fallback and empty selection covered; owner parity.
- Scenario parse test first had parser-API call compile failure, then expected JSON.parse_string errors on malformed input. Both invalid attempts retained. Clean RED18/1 errors0 after replacing invalid-syntax input by non-object valid null. GREEN23/0 errors0 before extra UTF8/emptyDict coverage; expanded cases now part of83gate matrix.
- Scenario audit5full bindingcalls195, bindinginclusive69.075ms before ->62.476ms after. Whole5full364.710 ->422.041ms (worse); no whole-HUD timing gain claimed. Only redundant parse work is established; native repeats pending.
-83gate matrix running; independent read-only review requested. No more product changes until finding.
- Ruling: base new task on current integrated Main rather than stale integration/core-foundation, because user explicitly continues just-integrated R4. No unrelated integration history included.
- Ruling: continue under previously authorized foreign GPU load; no isolated FPS acceptance. Cost: native whole-frame attribution remains limited.

- Final matrix83/83 exit0/errors0/sourceguards stable. New verifier35/0 identity,20/0 status,28/0 parse including UTF8 and empty dictionary.
- Native normal before68/0, afterA68/0, afterB68/0. Primary P95 40.494 ->33.098/33.945ms; Max46.373 ->38.089/38.831ms. Wholeframe P99 109.544 ->89.123/96.916ms; max177.367 ->160.657/169.312ms. Foreign GPU load not controlled, no isolated whole-game acceptance.
-11 Units,7 accepted Move/GO pairs, camera22,1x/full quality; max1 managerjob/frame in all runs. Native before/after images opened.
- Independent source review APPROVED scoped; no blocking defects. Nonblocking unforced Contact-Fire branch and malformed-JSON-green limitations recorded in review. No implementation change for these covered source paths.
